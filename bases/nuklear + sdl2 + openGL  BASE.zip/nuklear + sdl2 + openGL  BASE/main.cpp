#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdarg.h>
#include <string.h>
#include <math.h>
#include <assert.h>
#include <limits.h>
#include <time.h>

#include <SDL2/SDL.h>
#include <SDL2/SDL_opengl.h>
#include <GL/gl.h>

#define NK_INCLUDE_FIXED_TYPES
#define NK_INCLUDE_STANDARD_IO
#define NK_INCLUDE_STANDARD_VARARGS
#define NK_INCLUDE_DEFAULT_ALLOCATOR
#define NK_INCLUDE_VERTEX_BUFFER_OUTPUT
#define NK_INCLUDE_FONT_BAKING
#define NK_INCLUDE_DEFAULT_FONT
#define NK_IMPLEMENTATION
#define NK_SDL_GL2_IMPLEMENTATION
#include "nuklear.h"
#include "nuklear_sdl_gl2.h"

#define WINDOW_WIDTH 1200
#define WINDOW_HEIGHT 800

int main(int argc, char* argv[]) {
    (void)argc; (void)argv;
    
    // SDL setup - Configuración más simple para OpenGL 2.1
    SDL_SetHint(SDL_HINT_VIDEO_HIGHDPI_DISABLED, "0");
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER | SDL_INIT_EVENTS) != 0) {
        printf("Error al inicializar SDL: %s\n", SDL_GetError());
        return 1;
    }
    
    // Configuración OpenGL más compatible
    SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
    SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 24);
    SDL_GL_SetAttribute(SDL_GL_STENCIL_SIZE, 8);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 2);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 1);
    
    SDL_Window *win = SDL_CreateWindow("Nuklear + SDL2 + OpenGL Demo",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
        WINDOW_WIDTH, WINDOW_HEIGHT, 
        SDL_WINDOW_OPENGL | SDL_WINDOW_SHOWN | SDL_WINDOW_ALLOW_HIGHDPI);
    
    if (!win) {
        printf("Error al crear ventana: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }
    
    SDL_GLContext glContext = SDL_GL_CreateContext(win);
    if (!glContext) {
        printf("Error al crear contexto OpenGL: %s\n", SDL_GetError());
        SDL_DestroyWindow(win);
        SDL_Quit();
        return 1;
    }
    
    SDL_GL_MakeCurrent(win, glContext);
    SDL_GL_SetSwapInterval(1); // V-Sync
    
    // Información OpenGL
    printf("OpenGL Version: %s\n", glGetString(GL_VERSION));
    printf("OpenGL Renderer: %s\n", glGetString(GL_RENDERER));
    
    // Nuklear setup
    struct nk_context *ctx = nk_sdl_init(win);
    if (!ctx) {
        printf("Error al inicializar Nuklear\n");
        SDL_GL_DeleteContext(glContext);
        SDL_DestroyWindow(win);
        SDL_Quit();
        return 1;
    }
    
    // Configurar fuente
    struct nk_font_atlas *atlas;
    nk_sdl_font_stash_begin(&atlas);
    nk_sdl_font_stash_end();
    
    // Variables para la demo
    static float bg[4] = {0.10f, 0.18f, 0.24f, 1.0f};
    static float alpha = 0.8f;
    static int property = 20;
    static char text_buffer[256] = "Texto de ejemplo";
    static int checkbox_value = 1;
    static float slider_value = 0.5f;
    static int combo_selected = 0;
    static int radio_selected = 0;
    static float progress_value = 50.0f;
    static char multiline_buffer[512] = "Texto\nmultiple\nlinea";
    
    // Items para combo
    const char *combo_items[] = {"Item 1", "Item 2", "Item 3", "Item 4"};
    
    printf("Iniciando bucle principal...\n");
    
    int running = 1;
    while (running) {
        SDL_Event evt;
        nk_input_begin(ctx);
        while (SDL_PollEvent(&evt)) {
            if (evt.type == SDL_QUIT) {
                running = 0;
            }
            nk_sdl_handle_event(&evt);
        }
        nk_input_end(ctx);
        
        // === VENTANA 1: Controles Básicos ===
        if (nk_begin(ctx, "Controles Basicos", nk_rect(50, 50, 280, 400),
            NK_WINDOW_BORDER | NK_WINDOW_MOVABLE | NK_WINDOW_SCALABLE |
            NK_WINDOW_MINIMIZABLE | NK_WINDOW_TITLE)) {
            
            // Botones
            nk_layout_row_static(ctx, 30, 120, 2);
            if (nk_button_label(ctx, "Boton Normal")) {
                printf("Botón normal presionado!\n");
            }
            if (nk_button_label(ctx, "Boton Color")) {
                printf("Botón color presionado!\n");
            }
            
            // Separador
            nk_layout_row_dynamic(ctx, 10, 1);
            nk_spacing(ctx, 1);
            
            // Checkbox y toggle
            nk_layout_row_dynamic(ctx, 25, 1);
            nk_checkbox_label(ctx, "Checkbox activado", &checkbox_value);
            
            // Slider
            nk_layout_row_dynamic(ctx, 25, 1);
            nk_label(ctx, "Slider:", NK_TEXT_LEFT);
            slider_value = nk_slide_float(ctx, 0.0f, slider_value, 1.0f, 0.01f);
            
            // Property (spinner)
            nk_layout_row_dynamic(ctx, 25, 1);
            property = nk_propertyi(ctx, "Valor:", 0, property, 100, 1, 1);
            
            // Input de texto
            nk_layout_row_dynamic(ctx, 25, 1);
            nk_label(ctx, "Texto:", NK_TEXT_LEFT);
            nk_edit_string_zero_terminated(ctx, NK_EDIT_FIELD, text_buffer, 255, nk_filter_default);
            
            // Radio buttons
            nk_layout_row_dynamic(ctx, 25, 1);
            nk_label(ctx, "Radio Buttons:", NK_TEXT_LEFT);
            nk_layout_row_dynamic(ctx, 25, 3);
            if (nk_option_label(ctx, "Opcion A", radio_selected == 0)) radio_selected = 0;
            if (nk_option_label(ctx, "Opcion B", radio_selected == 1)) radio_selected = 1;
            if (nk_option_label(ctx, "Opcion C", radio_selected == 2)) radio_selected = 2;
            
            // Combo box
            nk_layout_row_dynamic(ctx, 25, 1);
            combo_selected = nk_combo(ctx, combo_items, 4, combo_selected, 25, nk_vec2(200, 200));
            
            // Progress bar
            nk_layout_row_dynamic(ctx, 25, 1);
            nk_label(ctx, "Progreso:", NK_TEXT_LEFT);
            nk_size prog_val = (nk_size)progress_value;
            nk_progress(ctx, &prog_val, 100, NK_MODIFIABLE);
            progress_value = (float)prog_val;
        }
        nk_end(ctx);
        
        // === VENTANA 2: Controles Avanzados ===
        if (nk_begin(ctx, "Controles Avanzados", nk_rect(350, 50, 320, 450),
            NK_WINDOW_BORDER | NK_WINDOW_MOVABLE | NK_WINDOW_SCALABLE |
            NK_WINDOW_MINIMIZABLE | NK_WINDOW_TITLE)) {
            
            // Color picker
            nk_layout_row_dynamic(ctx, 25, 1);
            nk_label(ctx, "Color de fondo:", NK_TEXT_LEFT);
            
            nk_layout_row_dynamic(ctx, 25, 1);
            struct nk_colorf color = {bg[0], bg[1], bg[2], bg[3]};
            if (nk_combo_begin_color(ctx, nk_rgb_cf(color), nk_vec2(nk_widget_width(ctx), 400))) {
                nk_layout_row_dynamic(ctx, 120, 1);
                color = nk_color_picker(ctx, color, NK_RGBA);
                
                bg[0] = color.r;
                bg[1] = color.g;
                bg[2] = color.b;
                bg[3] = color.a;
                
                nk_layout_row_dynamic(ctx, 25, 1);
                bg[0] = nk_propertyf(ctx, "#R:", 0, bg[0], 1.0f, 0.01f, 0.005f);
                bg[1] = nk_propertyf(ctx, "#G:", 0, bg[1], 1.0f, 0.01f, 0.005f);
                bg[2] = nk_propertyf(ctx, "#B:", 0, bg[2], 1.0f, 0.01f, 0.005f);
                bg[3] = nk_propertyf(ctx, "#A:", 0, bg[3], 1.0f, 0.01f, 0.005f);
                nk_combo_end(ctx);
            }
            
            // Transparencia general
            nk_layout_row_dynamic(ctx, 25, 1);
            alpha = nk_propertyf(ctx, "Transparencia:", 0.0f, alpha, 1.0f, 0.01f, 0.005f);
            
            // Área de texto multilínea
            nk_layout_row_dynamic(ctx, 25, 1);
            nk_label(ctx, "Texto multilinea:", NK_TEXT_LEFT);
            nk_layout_row_dynamic(ctx, 100, 1);
            nk_edit_string_zero_terminated(ctx, NK_EDIT_BOX, multiline_buffer, 511, nk_filter_default);
            
            // Grupo con contenido
            nk_layout_row_dynamic(ctx, 120, 1);
            if (nk_group_begin(ctx, "Grupo de Info", NK_WINDOW_BORDER)) {
                nk_layout_row_dynamic(ctx, 25, 1);
                nk_label(ctx, "Informacion del sistema:", NK_TEXT_CENTERED);
                
                static char info_buffer[128];
                snprintf(info_buffer, sizeof(info_buffer), "Propiedad: %d", property);
                nk_label(ctx, info_buffer, NK_TEXT_LEFT);
                
                snprintf(info_buffer, sizeof(info_buffer), "Slider: %.2f", slider_value);
                nk_label(ctx, info_buffer, NK_TEXT_LEFT);
                
                snprintf(info_buffer, sizeof(info_buffer), "Radio: %d", radio_selected);
                nk_label(ctx, info_buffer, NK_TEXT_LEFT);
                
                nk_group_end(ctx);
            }
            
            // Botones de acción
            nk_layout_row_dynamic(ctx, 30, 2);
            if (nk_button_label(ctx, "Reset")) {
                property = 20;
                slider_value = 0.5f;
                checkbox_value = 1;
                radio_selected = 0;
                combo_selected = 0;
                progress_value = 50.0f;
                strcpy(text_buffer, "Texto de ejemplo");
                printf("Valores reseteados!\n");
            }
            if (nk_button_label(ctx, "Imprimir")) {
                printf("=== ESTADO ACTUAL ===\n");
                printf("Checkbox: %s\n", checkbox_value ? "ON" : "OFF");
                printf("Slider: %.2f\n", slider_value);
                printf("Property: %d\n", property);
                printf("Radio: %d\n", radio_selected);
                printf("Combo: %s\n", combo_items[combo_selected]);
                printf("Texto: %s\n", text_buffer);
                printf("Progreso: %.1f%%\n", progress_value);
                printf("==================\n");
            }
        }
        nk_end(ctx);
        
        // === VENTANA 3: Panel de Estado ===
        if (nk_begin(ctx, "Panel de Estado", nk_rect(700, 50, 250, 200),
            NK_WINDOW_BORDER | NK_WINDOW_MOVABLE | NK_WINDOW_SCALABLE |
            NK_WINDOW_MINIMIZABLE | NK_WINDOW_TITLE)) {
            
            nk_layout_row_dynamic(ctx, 25, 1);
            nk_label(ctx, "Estado en tiempo real:", NK_TEXT_CENTERED);
            
            nk_layout_row_dynamic(ctx, 20, 1);
            static char status_buffer[64];
            
            snprintf(status_buffer, sizeof(status_buffer), "FPS: ~60");
            nk_label(ctx, status_buffer, NK_TEXT_LEFT);
            
            snprintf(status_buffer, sizeof(status_buffer), "Alpha: %.2f", alpha);
            nk_label(ctx, status_buffer, NK_TEXT_LEFT);
            
            snprintf(status_buffer, sizeof(status_buffer), "Check: %s", checkbox_value ? "SI" : "NO");
            nk_label(ctx, status_buffer, NK_TEXT_LEFT);
            
            snprintf(status_buffer, sizeof(status_buffer), "Combo: %s", combo_items[combo_selected]);
            nk_label(ctx, status_buffer, NK_TEXT_LEFT);
            
            // Barra de progreso en tiempo real
            nk_layout_row_dynamic(ctx, 20, 1);
            static float time_progress = 0.0f;
            time_progress += 0.5f;
            if (time_progress > 100.0f) time_progress = 0.0f;
            
            nk_size time_prog = (nk_size)time_progress;
            nk_progress(ctx, &time_prog, 100, NK_FIXED);
            
            nk_layout_row_dynamic(ctx, 15, 1);
            nk_label(ctx, "Animacion continua", NK_TEXT_CENTERED);
        }
        nk_end(ctx);
        
        // Render
        int display_w, display_h;
        SDL_GetWindowSize(win, &display_w, &display_h);
        glViewport(0, 0, display_w, display_h);
        glClear(GL_COLOR_BUFFER_BIT);
        glClearColor(bg[0] * alpha, bg[1] * alpha, bg[2] * alpha, bg[3]);
        
        // Render Nuklear
        nk_sdl_render(NK_ANTI_ALIASING_ON);
        
        SDL_GL_SwapWindow(win);
    }
    
    printf("Cerrando aplicacion...\n");
    
    nk_sdl_shutdown();
    SDL_GL_DeleteContext(glContext);
    SDL_DestroyWindow(win);
    SDL_Quit();
    return 0;
}