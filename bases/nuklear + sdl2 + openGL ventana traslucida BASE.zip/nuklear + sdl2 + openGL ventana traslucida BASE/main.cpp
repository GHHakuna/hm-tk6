#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdarg.h>
#include <string.h>
#include <math.h>
#include <assert.h>
#include <limits.h>
#include <time.h>

#include <SDL2/SDL.h>
#include <SDL2/SDL_opengl.h>
#include <GL/gl.h>

#define NK_INCLUDE_FIXED_TYPES
#define NK_INCLUDE_STANDARD_IO
#define NK_INCLUDE_STANDARD_VARARGS
#define NK_INCLUDE_DEFAULT_ALLOCATOR
#define NK_INCLUDE_VERTEX_BUFFER_OUTPUT
#define NK_INCLUDE_FONT_BAKING
#define NK_INCLUDE_DEFAULT_FONT
#define NK_IMPLEMENTATION
#define NK_SDL_GL2_IMPLEMENTATION
#include "nuklear.h"
#include "nuklear_sdl_gl2.h"

#define WINDOW_WIDTH 1200
#define WINDOW_HEIGHT 800

// Función para crear icono desde datos embebidos (como respaldo si no hay icon.ico)
SDL_Surface* create_fallback_icon() {
    // Icono simple 32x32 en formato RGBA
    static Uint32 icon_data[32*32];
    
    // Crear un icono con el color de tu tema (rojo/naranja)
    for (int y = 0; y < 32; y++) {
        for (int x = 0; x < 32; x++) {
            int index = y * 32 + x;
            
            // Crear un diseño simple: círculo con borde
            int center_x = 16, center_y = 16;
            double distance = sqrt((x - center_x) * (x - center_x) + (y - center_y) * (y - center_y));
            
            if (distance > 15) {
                // Fuera del círculo - transparente
                icon_data[index] = 0x00000000;
            } else if (distance > 13) {
                // Borde exterior - negro
                icon_data[index] = 0xFF000000;
            } else if (distance > 11) {
                // Anillo principal - tu color de acento (BF2809)
                icon_data[index] = 0xFF0928BF; // RGBA: BF2809 + alpha FF
            } else if (distance > 8) {
                // Anillo interior - color más claro
                icon_data[index] = 0xFF1932D3; // Versión más clara
            } else if (distance > 5) {
                // Centro - color intermedio
                icon_data[index] = 0xFF0A2A99;
            } else {
                // Núcleo central - muy claro
                icon_data[index] = 0xFF4C5CFF;
            }
        }
    }
    
    SDL_Surface* surface = SDL_CreateRGBSurfaceFrom(
        icon_data, 32, 32, 32, 32 * 4,
        0x000000FF, 0x0000FF00, 0x00FF0000, 0xFF000000
    );
    
    return surface;
}

// Función para cargar icono desde archivo ICO (Windows)
SDL_Surface* load_icon_from_file(const char* filename) {
    SDL_Surface* icon = SDL_LoadBMP(filename);
    if (!icon) {
        printf("No se pudo cargar el icono desde %s: %s\n", filename, SDL_GetError());
        printf("Usando icono por defecto embebido...\n");
        return create_fallback_icon();
    }
    return icon;
}

int main(int argc, char* argv[]) {
    (void)argc; (void)argv;
    
    // SDL setup - Configuración más simple para OpenGL 2.1
    SDL_SetHint(SDL_HINT_VIDEO_HIGHDPI_DISABLED, "0");
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER | SDL_INIT_EVENTS) != 0) {
        printf("Error al inicializar SDL: %s\n", SDL_GetError());
        return 1;
    }
    
    // Configuración OpenGL más compatible
    SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
    SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 24);
    SDL_GL_SetAttribute(SDL_GL_STENCIL_SIZE, 8);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 2);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 1);
    
    SDL_Window *win = SDL_CreateWindow("Tantra K6 - Nuklear GUI",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
        WINDOW_WIDTH, WINDOW_HEIGHT, 
        SDL_WINDOW_OPENGL | SDL_WINDOW_SHOWN | SDL_WINDOW_ALLOW_HIGHDPI);
    
    if (!win) {
        printf("Error al crear ventana: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }
    
    // === CONFIGURAR ICONO DE LA VENTANA ===
    // Primero intentar cargar desde archivo, luego usar el embebido
    SDL_Surface* icon = create_fallback_icon(); // Usar siempre el embebido por ahora
    
    if (icon) {
        SDL_SetWindowIcon(win, icon);
        printf("Icono establecido correctamente\n");
        SDL_FreeSurface(icon);
    } else {
        printf("No se pudo establecer el icono\n");
    }
    
    SDL_GLContext glContext = SDL_GL_CreateContext(win);
    if (!glContext) {
        printf("Error al crear contexto OpenGL: %s\n", SDL_GetError());
        SDL_DestroyWindow(win);
        SDL_Quit();
        return 1;
    }
    
    SDL_GL_MakeCurrent(win, glContext);
    SDL_GL_SetSwapInterval(1); // V-Sync
    
    // Información OpenGL
    printf("OpenGL Version: %s\n", glGetString(GL_VERSION));
    printf("OpenGL Renderer: %s\n", glGetString(GL_RENDERER));
    
    // Nuklear setup
    struct nk_context *ctx = nk_sdl_init(win);
    if (!ctx) {
        printf("Error al inicializar Nuklear\n");
        SDL_GL_DeleteContext(glContext);
        SDL_DestroyWindow(win);
        SDL_Quit();
        return 1;
    }
    
    // Configurar fuente
    struct nk_font_atlas *atlas;
    nk_sdl_font_stash_begin(&atlas);
    nk_sdl_font_stash_end();
    
    // Inicializar tabla de colores ANTES de usarla
    struct nk_color table[NK_COLOR_COUNT];
    nk_style_default(ctx);
    // Llenar la tabla con colores por defecto
    for (int i = 0; i < NK_COLOR_COUNT; i++) {
        table[i] = nk_rgba(128, 128, 128, 255); // Color gris por defecto
    }
    nk_style_from_table(ctx, table);
    
    // Colores personalizados
    struct nk_color title_color = nk_rgba(191, 40, 9, 255);      // 0xbf2809 - Títulos
    struct nk_color body_color = nk_rgba(45, 45, 49, 180);       // 0x2d2d31 con transparencia
    struct nk_color accent_color = nk_rgba(191, 40, 9, 200);     // Color de acento
    struct nk_color text_color = nk_rgba(220, 220, 220, 255);    // Texto claro
    struct nk_color transparent = nk_rgba(0, 0, 0, 0);           // Completamente transparente
    
    // Aplicar tema personalizado
    ctx->style.window.fixed_background = nk_style_item_color(body_color);
    ctx->style.window.background = body_color;
    ctx->style.window.border_color = nk_rgba(80, 80, 85, 255);
    ctx->style.window.combo_border_color = accent_color;
    ctx->style.window.contextual_border_color = accent_color;
    ctx->style.window.menu_border_color = accent_color;
    ctx->style.window.group_border_color = nk_rgba(80, 80, 85, 180);
    ctx->style.window.tooltip_border_color = accent_color;
    ctx->style.window.scrollbar_size = nk_vec2(16, 16);
    ctx->style.window.border_color = nk_rgba(100, 100, 105, 255);
    ctx->style.window.padding = nk_vec2(8, 4);
    ctx->style.window.spacing = nk_vec2(4, 4);
    
    // Personalizar header (títulos de ventana)
    ctx->style.window.header.normal = nk_style_item_color(title_color);
    ctx->style.window.header.hover = nk_style_item_color(nk_rgba(211, 50, 19, 255));
    ctx->style.window.header.active = nk_style_item_color(nk_rgba(171, 30, 0, 255));
    ctx->style.window.header.label_normal = nk_rgba(255, 255, 255, 255);
    ctx->style.window.header.label_hover = nk_rgba(255, 255, 255, 255);
    ctx->style.window.header.label_active = nk_rgba(255, 255, 255, 255);
    ctx->style.window.header.padding = nk_vec2(4, 4);
    ctx->style.window.header.label_padding = nk_vec2(4, 4);
    
    // Personalizar el botón de minimizar para que coincida con el header
    ctx->style.window.header.minimize_button.normal = nk_style_item_color(nk_rgba(171, 30, 0, 255));
    ctx->style.window.header.minimize_button.hover = nk_style_item_color(nk_rgba(211, 50, 19, 255));
    ctx->style.window.header.minimize_button.active = nk_style_item_color(nk_rgba(151, 20, 0, 255));
    ctx->style.window.header.minimize_button.text_normal = nk_rgba(255, 255, 255, 255);
    ctx->style.window.header.minimize_button.text_hover = nk_rgba(255, 255, 255, 255);
    ctx->style.window.header.minimize_button.text_active = nk_rgba(255, 255, 255, 255);
    ctx->style.window.header.minimize_button.border_color = nk_rgba(100, 20, 0, 255);
    
    // También personalizar el botón de cerrar
    ctx->style.window.header.close_button.normal = nk_style_item_color(nk_rgba(171, 30, 0, 255));
    ctx->style.window.header.close_button.hover = nk_style_item_color(nk_rgba(211, 50, 19, 255));
    ctx->style.window.header.close_button.active = nk_style_item_color(nk_rgba(151, 20, 0, 255));
    ctx->style.window.header.close_button.text_normal = nk_rgba(255, 255, 255, 255);
    ctx->style.window.header.close_button.text_hover = nk_rgba(255, 255, 255, 255);
    ctx->style.window.header.close_button.text_active = nk_rgba(255, 255, 255, 255);
    ctx->style.window.header.close_button.border_color = nk_rgba(100, 20, 0, 255);
    
    // Personalizar botones
    ctx->style.button.normal = nk_style_item_color(nk_rgba(60, 60, 65, 255));
    ctx->style.button.hover = nk_style_item_color(accent_color);
    ctx->style.button.active = nk_style_item_color(nk_rgba(151, 20, 0, 255));
    ctx->style.button.text_normal = text_color;
    ctx->style.button.text_hover = nk_rgba(255, 255, 255, 255);
    ctx->style.button.text_active = nk_rgba(255, 255, 255, 255);
    ctx->style.button.border_color = nk_rgba(80, 80, 85, 255);
    
    // Personalizar texto y labels
    ctx->style.text.color = text_color;
    
    // Personalizar controles de entrada
    ctx->style.edit.normal = nk_style_item_color(nk_rgba(35, 35, 39, 255));
    ctx->style.edit.hover = nk_style_item_color(nk_rgba(40, 40, 44, 255));
    ctx->style.edit.active = nk_style_item_color(nk_rgba(50, 50, 54, 255));
    ctx->style.edit.text_normal = text_color;
    ctx->style.edit.text_hover = text_color;
    ctx->style.edit.text_active = nk_rgba(255, 255, 255, 255);
    ctx->style.edit.border_color = accent_color;
    
    // PERSONALIZAR SLIDERS - Sin fondo ni borde, solo línea y cursor
    ctx->style.slider.normal = nk_style_item_color(transparent);         // Fondo transparente
    ctx->style.slider.hover = nk_style_item_color(transparent);          // Fondo transparente en hover
    ctx->style.slider.active = nk_style_item_color(transparent);         // Fondo transparente cuando activo
    ctx->style.slider.border_color = transparent;                        // Sin borde
    ctx->style.slider.bar_normal = nk_rgba(100, 100, 105, 255);          // Color de la barra/línea
    ctx->style.slider.bar_hover = nk_rgba(120, 120, 125, 255);           // Color de la barra en hover
    ctx->style.slider.bar_active = nk_rgba(140, 140, 145, 255);          // Color de la barra cuando activo
    ctx->style.slider.bar_filled = accent_color;                         // Color de la parte llena
    ctx->style.slider.cursor_normal = nk_style_item_color(accent_color); // Cursor/botón
    ctx->style.slider.cursor_hover = nk_style_item_color(nk_rgba(211, 50, 19, 255));
    ctx->style.slider.cursor_active = nk_style_item_color(nk_rgba(171, 30, 0, 255));
    ctx->style.slider.cursor_size = nk_vec2(16, 16);                     // Tamaño del cursor
    ctx->style.slider.border = 0;                                        // Sin borde
    
    // Personalizar progress bars - similar a sliders
    ctx->style.progress.normal = nk_style_item_color(transparent);
    ctx->style.progress.hover = nk_style_item_color(transparent);
    ctx->style.progress.active = nk_style_item_color(transparent);
    ctx->style.progress.border_color = transparent;                      // Sin borde
    ctx->style.progress.cursor_normal = nk_style_item_color(accent_color);
    ctx->style.progress.cursor_hover = nk_style_item_color(nk_rgba(211, 50, 19, 255));
    ctx->style.progress.cursor_active = nk_style_item_color(nk_rgba(171, 30, 0, 255));
    ctx->style.progress.border = 0;                                      // Sin borde
    
    // Personalizar checkboxes
    ctx->style.checkbox.normal = nk_style_item_color(nk_rgba(50, 50, 55, 255));
    ctx->style.checkbox.hover = nk_style_item_color(nk_rgba(60, 60, 65, 255));
    ctx->style.checkbox.active = nk_style_item_color(nk_rgba(70, 70, 75, 255));
    ctx->style.checkbox.cursor_normal = nk_style_item_color(accent_color);
    ctx->style.checkbox.cursor_hover = nk_style_item_color(nk_rgba(211, 50, 19, 255));
    ctx->style.checkbox.text_normal = text_color;
    ctx->style.checkbox.text_hover = nk_rgba(255, 255, 255, 255);
    ctx->style.checkbox.text_active = nk_rgba(255, 255, 255, 255);
    ctx->style.checkbox.border_color = nk_rgba(80, 80, 85, 255);
    
    // Personalizar radio buttons (option)
    ctx->style.option.normal = nk_style_item_color(nk_rgba(50, 50, 55, 255));
    ctx->style.option.hover = nk_style_item_color(nk_rgba(60, 60, 65, 255));
    ctx->style.option.active = nk_style_item_color(nk_rgba(70, 70, 75, 255));
    ctx->style.option.cursor_normal = nk_style_item_color(accent_color);
    ctx->style.option.cursor_hover = nk_style_item_color(nk_rgba(211, 50, 19, 255));
    ctx->style.option.text_normal = text_color;
    ctx->style.option.text_hover = nk_rgba(255, 255, 255, 255);
    ctx->style.option.text_active = nk_rgba(255, 255, 255, 255);
    ctx->style.option.border_color = nk_rgba(80, 80, 85, 255);
    
    // Personalizar combos
    ctx->style.combo.normal = nk_style_item_color(nk_rgba(50, 50, 55, 255));
    ctx->style.combo.hover = nk_style_item_color(nk_rgba(60, 60, 65, 255));
    ctx->style.combo.active = nk_style_item_color(nk_rgba(70, 70, 75, 255));
    ctx->style.combo.border_color = accent_color;
    ctx->style.combo.label_normal = text_color;
    ctx->style.combo.label_hover = nk_rgba(255, 255, 255, 255);
    ctx->style.combo.label_active = nk_rgba(255, 255, 255, 255);
    ctx->style.combo.symbol_normal = text_color;
    ctx->style.combo.symbol_hover = nk_rgba(255, 255, 255, 255);
    ctx->style.combo.symbol_active = nk_rgba(255, 255, 255, 255);
    
    // Personalizar el botón del combo
    ctx->style.combo.button.normal = nk_style_item_color(nk_rgba(60, 60, 65, 255));
    ctx->style.combo.button.hover = nk_style_item_color(accent_color);
    ctx->style.combo.button.active = nk_style_item_color(nk_rgba(151, 20, 0, 255));
    ctx->style.combo.button.text_normal = text_color;
    ctx->style.combo.button.text_hover = nk_rgba(255, 255, 255, 255);
    ctx->style.combo.button.text_active = nk_rgba(255, 255, 255, 255);
    
    // Personalizar contextual (menú desplegable del combo)
    ctx->style.contextual_button.normal = nk_style_item_color(nk_rgba(45, 45, 49, 255));
    ctx->style.contextual_button.hover = nk_style_item_color(accent_color);
    ctx->style.contextual_button.active = nk_style_item_color(nk_rgba(151, 20, 0, 255));
    ctx->style.contextual_button.text_normal = text_color;
    ctx->style.contextual_button.text_hover = nk_rgba(255, 255, 255, 255);
    ctx->style.contextual_button.text_active = nk_rgba(255, 255, 255, 255);
    ctx->style.contextual_button.border_color = nk_rgba(80, 80, 85, 255);
    
    // Personalizar el fondo del menú contextual
    ctx->style.window.contextual_border_color = accent_color;
    ctx->style.window.combo_border_color = accent_color;
    
    // Variables para la demo
    static float bg[4] = {0.15f, 0.15f, 0.18f, 1.0f}; // Color de fondo del contenedor principal
    static float alpha = 0.9f; // Transparencia inicial más sutil
    static int property = 20;
    static char text_buffer[256] = "Texto de ejemplo";
    static int checkbox_value = 1;
    static float slider_value = 0.5f;
    static int combo_selected = 0;
    static int radio_selected = 0;
    static float progress_value = 50.0f;
    static char multiline_buffer[512] = "Texto\nmultiple\nlinea";
    static float window_alpha = 0.95f; // Control de transparencia específico para ventanas
    
    // Items para combo
    const char *combo_items[] = {"Item 1", "Item 2", "Item 3", "Item 4"};
    
    printf("Iniciando bucle principal...\n");
    
    int running = 1;
    while (running) {
        SDL_Event evt;
        nk_input_begin(ctx);
        while (SDL_PollEvent(&evt)) {
            if (evt.type == SDL_QUIT) {
                running = 0;
            }
            nk_sdl_handle_event(&evt);
        }
        nk_input_end(ctx);
        
        // === VENTANA 1: Controles Básicos ===
        if (nk_begin(ctx, "Controles Basicos", nk_rect(50, 50, 280, 450),
            NK_WINDOW_BORDER | NK_WINDOW_MOVABLE | NK_WINDOW_SCALABLE |
            NK_WINDOW_MINIMIZABLE | NK_WINDOW_TITLE)) {
            
            // Botones
            nk_layout_row_static(ctx, 30, 120, 2);
            if (nk_button_label(ctx, "Boton Normal")) {
                printf("Botón normal presionado!\n");
            }
            if (nk_button_label(ctx, "Boton Color")) {
                printf("Botón color presionado!\n");
            }
            
            // Separador
            nk_layout_row_dynamic(ctx, 10, 1);
            nk_spacing(ctx, 1);
            
            // Checkbox y toggle
            nk_layout_row_dynamic(ctx, 25, 1);
            nk_checkbox_label(ctx, "Checkbox activado", &checkbox_value);
            
            // Slider mejorado
            nk_layout_row_dynamic(ctx, 25, 1);
            nk_label(ctx, "Slider:", NK_TEXT_LEFT);
            nk_layout_row_dynamic(ctx, 20, 1);
            slider_value = nk_slide_float(ctx, 0.0f, slider_value, 1.0f, 0.01f);
            
            // SPINNER ALTERNATIVO - Usando botones + y - con campo de texto
            nk_layout_row_dynamic(ctx, 25, 1);
            nk_label(ctx, "Spinner (valor):", NK_TEXT_LEFT);
            nk_layout_row_static(ctx, 25, 30, 3);
            if (nk_button_label(ctx, "-")) {
                if (property > 0) property--;
            }
            
            // Campo de texto en el medio mostrando el valor
            static char spinner_buffer[16];
            snprintf(spinner_buffer, sizeof(spinner_buffer), "%d", property);
            nk_edit_string_zero_terminated(ctx, NK_EDIT_FIELD, spinner_buffer, 15, nk_filter_decimal);
            // Convertir de vuelta a entero
            int new_value = atoi(spinner_buffer);
            if (new_value >= 0 && new_value <= 100) {
                property = new_value;
            }
            
            if (nk_button_label(ctx, "+")) {
                if (property < 100) property++;
            }
            
            // Alternativa 2: Spinner usando solo botones con display
            nk_layout_row_dynamic(ctx, 25, 1);
            nk_label(ctx, "Spinner (botones):", NK_TEXT_LEFT);
            nk_layout_row_static(ctx, 25, 80, 3);
            if (nk_button_label(ctx, "- Menos")) {
                if (property > 0) property--;
            }
            
            static char display_buffer[32];
            snprintf(display_buffer, sizeof(display_buffer), " %d ", property);
            nk_label(ctx, display_buffer, NK_TEXT_CENTERED);
            
            if (nk_button_label(ctx, "+ Mas")) {
                if (property < 100) property++;
            }
            
            // Input de texto
            nk_layout_row_dynamic(ctx, 25, 1);
            nk_label(ctx, "Texto:", NK_TEXT_LEFT);
            nk_edit_string_zero_terminated(ctx, NK_EDIT_FIELD, text_buffer, 255, nk_filter_default);
            
            // Radio buttons
            nk_layout_row_dynamic(ctx, 25, 1);
            nk_label(ctx, "Radio Buttons:", NK_TEXT_LEFT);
            nk_layout_row_dynamic(ctx, 25, 3);
            if (nk_option_label(ctx, "Opcion A", radio_selected == 0)) radio_selected = 0;
            if (nk_option_label(ctx, "Opcion B", radio_selected == 1)) radio_selected = 1;
            if (nk_option_label(ctx, "Opcion C", radio_selected == 2)) radio_selected = 2;
            
            // Combo box
            nk_layout_row_dynamic(ctx, 25, 1);
            combo_selected = nk_combo(ctx, combo_items, 4, combo_selected, 25, nk_vec2(200, 200));
            
            // Progress bar
            nk_layout_row_dynamic(ctx, 25, 1);
            nk_label(ctx, "Progreso:", NK_TEXT_LEFT);
            nk_layout_row_dynamic(ctx, 20, 1);
            nk_size prog_val = (nk_size)progress_value;
            nk_progress(ctx, &prog_val, 100, NK_MODIFIABLE);
            progress_value = (float)prog_val;
        }
        nk_end(ctx);
        
        // === VENTANA 2: Controles Avanzados ===
        if (nk_begin(ctx, "Controles Avanzados", nk_rect(350, 50, 320, 450),
            NK_WINDOW_BORDER | NK_WINDOW_MOVABLE | NK_WINDOW_SCALABLE |
            NK_WINDOW_MINIMIZABLE | NK_WINDOW_TITLE)) {
            
            // Color picker
            nk_layout_row_dynamic(ctx, 25, 1);
            nk_label(ctx, "Color de fondo:", NK_TEXT_LEFT);
            
            nk_layout_row_dynamic(ctx, 25, 1);
            struct nk_colorf color = {bg[0], bg[1], bg[2], bg[3]};
            if (nk_combo_begin_color(ctx, nk_rgb_cf(color), nk_vec2(nk_widget_width(ctx), 400))) {
                nk_layout_row_dynamic(ctx, 120, 1);
                color = nk_color_picker(ctx, color, NK_RGBA);
                
                bg[0] = color.r;
                bg[1] = color.g;
                bg[2] = color.b;
                bg[3] = color.a;
                
                nk_layout_row_dynamic(ctx, 25, 1);
                bg[0] = nk_propertyf(ctx, "#R:", 0, bg[0], 1.0f, 0.01f, 0.005f);
                bg[1] = nk_propertyf(ctx, "#G:", 0, bg[1], 1.0f, 0.01f, 0.005f);
                bg[2] = nk_propertyf(ctx, "#B:", 0, bg[2], 1.0f, 0.01f, 0.005f);
                bg[3] = nk_propertyf(ctx, "#A:", 0, bg[3], 1.0f, 0.01f, 0.005f);
                nk_combo_end(ctx);
            }
            
            // Transparencia general
            nk_layout_row_dynamic(ctx, 25, 1);
            alpha = nk_propertyf(ctx, "Transparencia:", 0.0f, alpha, 1.0f, 0.01f, 0.005f);
            
            // Control específico de transparencia de ventanas
            nk_layout_row_dynamic(ctx, 25, 1);
            window_alpha = nk_propertyf(ctx, "Alpha Ventanas:", 0.1f, window_alpha, 1.0f, 0.01f, 0.005f);
            
            // Área de texto multilínea
            nk_layout_row_dynamic(ctx, 25, 1);
            nk_label(ctx, "Texto multilinea:", NK_TEXT_LEFT);
            nk_layout_row_dynamic(ctx, 100, 1);
            nk_edit_string_zero_terminated(ctx, NK_EDIT_BOX, multiline_buffer, 511, nk_filter_default);
            
            // Grupo con contenido
            nk_layout_row_dynamic(ctx, 120, 1);
            if (nk_group_begin(ctx, "Grupo de Info", NK_WINDOW_BORDER)) {
                nk_layout_row_dynamic(ctx, 25, 1);
                nk_label(ctx, "Informacion del sistema:", NK_TEXT_CENTERED);
                
                static char info_buffer[128];
                snprintf(info_buffer, sizeof(info_buffer), "Propiedad: %d", property);
                nk_label(ctx, info_buffer, NK_TEXT_LEFT);
                
                snprintf(info_buffer, sizeof(info_buffer), "Slider: %.2f", slider_value);
                nk_label(ctx, info_buffer, NK_TEXT_LEFT);
                
                snprintf(info_buffer, sizeof(info_buffer), "Radio: %d", radio_selected);
                nk_label(ctx, info_buffer, NK_TEXT_LEFT);
                
                nk_group_end(ctx);
            }
            
            // Botones de acción
            nk_layout_row_dynamic(ctx, 30, 2);
            if (nk_button_label(ctx, "Reset")) {
                property = 20;
                slider_value = 0.5f;
                checkbox_value = 1;
                radio_selected = 0;
                combo_selected = 0;
                progress_value = 50.0f;
                strcpy(text_buffer, "Texto de ejemplo");
                printf("Valores reseteados!\n");
            }
            if (nk_button_label(ctx, "Imprimir")) {
                printf("=== ESTADO ACTUAL ===\n");
                printf("Checkbox: %s\n", checkbox_value ? "ON" : "OFF");
                printf("Slider: %.2f\n", slider_value);
                printf("Property: %d\n", property);
                printf("Radio: %d\n", radio_selected);
                printf("Combo: %s\n", combo_items[combo_selected]);
                printf("Texto: %s\n", text_buffer);
                printf("Progreso: %.1f%%\n", progress_value);
                printf("==================\n");
            }
        }
        nk_end(ctx);
        
        // === VENTANA 3: Panel de Estado ===
        if (nk_begin(ctx, "Panel de Estado", nk_rect(700, 50, 250, 200),
            NK_WINDOW_BORDER | NK_WINDOW_MOVABLE | NK_WINDOW_SCALABLE |
            NK_WINDOW_MINIMIZABLE | NK_WINDOW_TITLE)) {
            
            nk_layout_row_dynamic(ctx, 25, 1);
            nk_label(ctx, "Estado en tiempo real:", NK_TEXT_CENTERED);
            
            nk_layout_row_dynamic(ctx, 20, 1);
            static char status_buffer[64];
            
            snprintf(status_buffer, sizeof(status_buffer), "FPS: ~60");
            nk_label(ctx, status_buffer, NK_TEXT_LEFT);
            
            snprintf(status_buffer, sizeof(status_buffer), "Alpha: %.2f", alpha);
            nk_label(ctx, status_buffer, NK_TEXT_LEFT);
            
            snprintf(status_buffer, sizeof(status_buffer), "Check: %s", checkbox_value ? "SI" : "NO");
            nk_label(ctx, status_buffer, NK_TEXT_LEFT);
            
            snprintf(status_buffer, sizeof(status_buffer), "Combo: %s", combo_items[combo_selected]);
            nk_label(ctx, status_buffer, NK_TEXT_LEFT);
            
            // Barra de progreso en tiempo real
            nk_layout_row_dynamic(ctx, 20, 1);
            static float time_progress = 0.0f;
            time_progress += 0.5f;
            if (time_progress > 100.0f) time_progress = 0.0f;
            
            nk_size time_prog = (nk_size)time_progress;
            nk_progress(ctx, &time_prog, 100, NK_FIXED);
            
            nk_layout_row_dynamic(ctx, 15, 1);
            nk_label(ctx, "Animacion continua", NK_TEXT_CENTERED);
        }
        nk_end(ctx);
        
        // Render con efectos mejorados
        int display_w, display_h;
        SDL_GetWindowSize(win, &display_w, &display_h);
        glViewport(0, 0, display_w, display_h);
        
        // Habilitar blending para transparencias
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        
        // Limpiar con color de fondo del contenedor principal
        glClear(GL_COLOR_BUFFER_BIT);
        glClearColor(bg[0] * alpha, bg[1] * alpha, bg[2] * alpha, bg[3]);
        
        // Aplicar efecto de transparencia dinámico
        struct nk_color body_dynamic = nk_rgba(45, 45, 49, (int)(255 * window_alpha * 0.7f));
        
        // Actualizar colores del body con transparencia
        ctx->style.window.fixed_background = nk_style_item_color(body_dynamic);
        ctx->style.window.background = body_dynamic;
        ctx->style.window.group_border_color = nk_rgba(80, 80, 85, (int)(180 * window_alpha));
        
        // Efecto de profundidad con bordes graduales
        ctx->style.window.border = 1.5f;
        ctx->style.window.border_color = nk_rgba(0, 0, 0, (int)(120 * window_alpha));
        
        // Los títulos mantienen su color sólido (sin transparencia)
        struct nk_color title_solid = nk_rgba(191, 40, 9, 255);
        ctx->style.window.header.normal = nk_style_item_color(title_solid);
        ctx->style.window.header.hover = nk_style_item_color(nk_rgba(211, 50, 19, 255));
        ctx->style.window.header.active = nk_style_item_color(nk_rgba(171, 30, 0, 255));
        
        // Actualizar controles con la nueva transparencia
        ctx->style.edit.normal = nk_style_item_color(nk_rgba(35, 35, 39, (int)(255 * window_alpha)));
        ctx->style.edit.hover = nk_style_item_color(nk_rgba(40, 40, 44, (int)(255 * window_alpha)));
        ctx->style.edit.active = nk_style_item_color(nk_rgba(50, 50, 54, (int)(255 * window_alpha)));
        
        ctx->style.button.normal = nk_style_item_color(nk_rgba(60, 60, 65, (int)(255 * window_alpha)));
        
        // Actualizar checkboxes con transparencia
        ctx->style.checkbox.normal = nk_style_item_color(nk_rgba(50, 50, 55, (int)(255 * window_alpha)));
        ctx->style.checkbox.hover = nk_style_item_color(nk_rgba(60, 60, 65, (int)(255 * window_alpha)));
        ctx->style.checkbox.active = nk_style_item_color(nk_rgba(70, 70, 75, (int)(255 * window_alpha)));
        
        // Actualizar radio buttons con transparencia
        ctx->style.option.normal = nk_style_item_color(nk_rgba(50, 50, 55, (int)(255 * window_alpha)));
        ctx->style.option.hover = nk_style_item_color(nk_rgba(60, 60, 65, (int)(255 * window_alpha)));
        ctx->style.option.active = nk_style_item_color(nk_rgba(70, 70, 75, (int)(255 * window_alpha)));
        
        // Actualizar combos con transparencia
        ctx->style.combo.normal = nk_style_item_color(nk_rgba(50, 50, 55, (int)(255 * window_alpha)));
        ctx->style.combo.hover = nk_style_item_color(nk_rgba(60, 60, 65, (int)(255 * window_alpha)));
        ctx->style.combo.active = nk_style_item_color(nk_rgba(70, 70, 75, (int)(255 * window_alpha)));
        ctx->style.combo.button.normal = nk_style_item_color(nk_rgba(60, 60, 65, (int)(255 * window_alpha)));
        
        // Actualizar menú contextual (dropdown del combo) con transparencia
        ctx->style.contextual_button.normal = nk_style_item_color(nk_rgba(45, 45, 49, (int)(255 * window_alpha * 0.95f)));
        ctx->style.contextual_button.hover = nk_style_item_color(nk_rgba(191, 40, 9, (int)(255 * window_alpha)));
        ctx->style.contextual_button.active = nk_style_item_color(nk_rgba(151, 20, 0, (int)(255 * window_alpha)));
        
        // Renderizar con antialiasing y efectos
        nk_sdl_render(NK_ANTI_ALIASING_ON);
        
        glDisable(GL_BLEND);
        
        SDL_GL_SwapWindow(win);
    }
    
    printf("Cerrando aplicacion...\n");
    
    nk_sdl_shutdown();
    SDL_GL_DeleteContext(glContext);
    SDL_DestroyWindow(win);
    SDL_Quit();
    return 0;
}